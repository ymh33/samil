package com.oracle.samil.Amodel;

import lombok.Data;

@Data
public class CostCode {
	private int 	codeNum; 		//비용항목코드
	private String 	codeName;		//비용항목명칭
}
