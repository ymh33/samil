package com.oracle.samil.Mhrepository;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class SalRepositoryI implements SalRepository {

}
