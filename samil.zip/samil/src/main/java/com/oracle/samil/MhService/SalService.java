package com.oracle.samil.MhService;

import java.util.List;

import com.oracle.samil.Amodel.Emp;

public interface SalService {

	int totalSal();

	List<Emp> totalEmp(Emp emp);

}
