package com.oracle.samil.Mhrepository;

public interface SalRepository {

}
